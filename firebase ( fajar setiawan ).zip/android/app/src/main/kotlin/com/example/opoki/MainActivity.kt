package com.example.opoki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
